from django.contrib import admin
from .models import DFrame

admin.site.register(DFrame)
