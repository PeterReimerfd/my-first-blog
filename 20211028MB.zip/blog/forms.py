#from django import forms

#from .models import DFrame
#The two lines above should be unmuted and used once there's real code below


#class PostForm(forms.ModelForm):
#    class Meta:
#        model=Post
#        fields=('title','text',)